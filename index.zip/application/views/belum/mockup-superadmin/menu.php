<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">

        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="menu-title">SUPER ADMIN</li><!-- /.menu-title -->
                <li>
                    <a href="<?php echo base_url();?>superadmin/buka"> <i class="menu-icon fa fa-male"></i>Membuka sistem</a>
                </li>
                <li class="menu-title">CLIENTS</li><!-- /.menu-title -->
                <li>
                    <a href="<?php echo base_url();?>superadmin/project/1"> <i class="menu-icon fa fa-male"></i>SMAK 1 Penabur</a>
                </li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</aside>

