
<div class="row">
    <div class="col-xl-12"> 
        <div class="card">
            <div class="card-body">
                <h4 class="box-title">Tugas </h4>
            </div>
            <div class="card-body">
                <div class="table-stats">
                    <table class="table table-stripped" id = "bootstrap-data-table-export">
                        <thead>
                            <tr>
                                <th class="serial">#</th>
                                <th>ID</th>
                                <th>Mata Pelajaran</th>
                                <th>Guru</th>
                                <th>Dateline</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>KIM</td>
                                <td>KIMIA</td>
                                <td>KURNIA</td>
                                <td>28/02/2019</td>
                                <td>NOT DONE</td>
                            </tr>
                        </tbody>
                    </table>
                </div> <!-- /.table-stats -->
            </div>
        </div> <!-- /.card -->
    </div>  <!-- /.col-lg-8 -->

</div> 