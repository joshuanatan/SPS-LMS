<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">

        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="menu-title">ADMIN</li><!-- /.menu-title -->
                <li>
                    <a href="<?php echo base_url();?>admin/index"> <i class="menu-icon fa fa-male"></i>Dashboard</a>
                </li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</aside>

