<div class = "row">   
    <div class="col-md-12 col-lg-4">
        <div class="card">
            <div class="card-body">  
                <!-- <h4 class="box-title">Chandler</h4> -->
                <div class="calender-cont widget-calender">
                    <div id="calendar"></div>
                </div>
            </div>
        </div><!-- /.card -->
    </div> <!-- /.col-md-4 -->
</div> 