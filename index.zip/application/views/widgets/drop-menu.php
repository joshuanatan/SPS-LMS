<li class="menu-item-has-children dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-table"></i>Mata Pelajaran Kelas</a>
    <ul class="sub-menu children dropdown-menu">
        <li><i class="fa fa-table"></i><a href="<?php echo base_url();?>matapelajarankelas/ipa">IPA</a></li>
        <li><i class="fa fa-table"></i><a href="<?php echo base_url();?>matapelajarankelas/ips">IPS</a></li>
    </ul>
</li>