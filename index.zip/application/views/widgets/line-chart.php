<div class="card">
    <div class="card-body">
        <h4 class="mb-3">Line Chart </h4>
        <canvas id="lineChart"></canvas>
    </div>
</div>