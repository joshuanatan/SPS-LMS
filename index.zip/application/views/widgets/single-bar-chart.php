<div class="col-lg-6">
    <div class="card">
        <div class="card-body">
            <h4 class="mb-3">Single Bar Chart </h4>
            <canvas id="singelBarChart"></canvas>
        </div>
    </div>
</div>