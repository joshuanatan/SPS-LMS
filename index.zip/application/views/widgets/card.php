<div class="row">
    <div class="col-md-4"> <!-- ganti ukuran -->
        <div class="card">
            <div class="card-header">
                <strong class="card-title mb-3">Nama Mata Pelajaran</strong>
            </div>
            <div class="card-body">
                <div class="mx-auto d-block">
                    <h5 class="text-sm-center mt-2 mb-1">Nama Guru</h5>
                    <div class="location text-sm-center">Hari Pelajarannya</div>
                </div>
                <hr>
                
            </div>
        </div>
    </div>
    <!-- diisini kalau mau nambah card sebaris -->
</div>