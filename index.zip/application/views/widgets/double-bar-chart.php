<div class="col-lg-6">
    <div class="card">
        <div class="card-body">
            <h4 class="mb-3">Bar chart </h4>
            <canvas id="barChart"></canvas>
        </div>
    </div>
</div>