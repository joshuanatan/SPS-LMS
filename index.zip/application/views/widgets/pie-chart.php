<div class="col-lg-3">
        <div class="card">
            <div class="card-body">
                <h4 class="mb-3">Pie Chart </h4>
                <canvas id="pieChart"></canvas>
            </div>
        </div>
    </div>