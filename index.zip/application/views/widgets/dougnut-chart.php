<div class="col-lg-12">
    <div class="card">
        <div class="card-body">
            <h4 class="mb-3">Doughut Chart </h4>
            <canvas id="doughutChart"></canvas>
        </div>
    </div>
</div>