<script src="<?php echo base_url();?>assets/js/lib/peitychart/jquery.peity.min.js"></script>
    <!-- scripit init-->
    <script src="<?php echo base_url();?>assets/js/lib/peitychart/peitychart.init.js"></script>