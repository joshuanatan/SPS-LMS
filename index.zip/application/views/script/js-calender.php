
    <script src="<?php echo base_url();?>assets/js/lib/moment/moment.js"></script>
    <script src="<?php echo base_url();?>assets/calendar/fullcalendar.min.js"></script>
    <script src="<?php echo base_url();?>assets/calendar/fullcalendar-init.js"></script>