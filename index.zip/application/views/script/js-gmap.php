
    <script src="https://maps.googleapis.com/maps/api/js?v=3&sensor=false"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD2jlT6C_to6X1mMvR9yRWeRvpIgTXgddM"></script>
    <script src="<?php echo base_url();?>assets/js/lib/gmap/gmaps.js"></script>
    <script src="<?php echo base_url();?>assets/js/lib/gmap/gmap.init.js"></script>