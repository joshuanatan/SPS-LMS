<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">

        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">
                
                <li class="menu-title">Interface Guru</li><!-- /.menu-title -->
                <li>
                    <!--<a href="<?php echo base_url();?>welcome/assignmentguru"> <i class="menu-icon fa fa-cogs"></i>Assignments</a>-->
                    <a href="<?php echo base_url();?>user/guru/assignment"> <i class="menu-icon fa fa-cogs"></i>Assignments</a>
                </li>
                <li>
                    <!--<a href="<?php echo base_url();?>welcome/gradeguru"> <i class="menu-icon fa fa-table"></i>Grade</a>-->
                    <a href="<?php echo base_url();?>user/guru/grade"> <i class="menu-icon fa fa-table"></i>Grade</a>
                </li>
                <li>
                    <!--<a href="<?php echo base_url();?>welcome/attendanceguru"> <i class="menu-icon fa fa-globe"></i>Attendance</a>-->
                    <a href="<?php echo base_url();?>user/guru/attendance"> <i class="menu-icon fa fa-globe"></i>Attendance</a>
                </li>
                <li>
                    <!--<a href="<?php echo base_url();?>welcome/announcementguru"> <i class="menu-icon fa fa-th"></i>Announcement</a>-->
                    <a href="<?php echo base_url();?>user/guru/announcement"> <i class="menu-icon fa fa-th"></i>Announcement</a>
                </li>
                <hr/>
                <hr/>
                
                <li>
                    <!--<a href="<?php echo base_url();?>welcome/assignmentguru"> <i class="menu-icon fa fa-cogs"></i>Assignments</a>-->
                    <a href="<?php echo base_url();?>user/walikelas/index"> <i class="menu-icon fa fa-cogs"></i>Wali Kelas</a>
                </li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</aside>

