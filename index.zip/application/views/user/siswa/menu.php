<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">

        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">
                
                <li class="menu-title">Siswa</li><!-- /.menu-title -->
                <li>
                    <a href="<?php echo base_url();?>user/siswa/assignment"> <i class="menu-icon fa fa-cogs"></i>Assignments</a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>user/siswa/grade"> <i class="menu-icon fa fa-table"></i>Grade</a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>user/siswa/attendance"> <i class="menu-icon fa fa-globe"></i>Attendance</a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>user/siswa/announcement"> <i class="menu-icon fa fa-th"></i>Announcement</a>
                </li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</aside>

