<!--
<button class="search-trigger"><i class="fa fa-search"></i></button>
<div class="form-inline">
    <form class="search-form">
        <input class="form-control mr-sm-2" type="text" placeholder="Search ..." aria-label="Search">
        <button class="search-close" type="submit"><i class="fa fa-close"></i></button>
    </form>
</div>
-->