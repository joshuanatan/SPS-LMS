<div id="right-panel" class="right-panel">
