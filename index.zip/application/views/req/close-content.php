    </div><!-- .animated -->
</div><!-- .content -->