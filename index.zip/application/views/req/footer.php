<footer class="site-footer">
    <div class="footer-inner">
        <div class="row">
            <div class="col-sm-6">
                Sekolah ABC
            </div>
            <div class="col-sm-6 text-right">
                Designed by <a href="https://colorlib.com">iSupport </a>
            </div>
        </div>
    </div>
</footer>

