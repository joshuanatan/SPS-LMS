<!--
<div class="dropdown for-message">
    <button class="btn btn-secondary dropdown-toggle" type="button" id="message" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fa fa-envelope"></i>
        <span class="count bg-primary">4</span>
    </button>
    <div class="dropdown-menu" aria-labelledby="message">
        <p class="red">You have 4 Mails</p>
        <a class="dropdown-item media" href="#">
            <span class="photo media-left"><img alt="avatar" src="images/avatar/1.jpg"></span>
            <div class="message media-body">
                <span class="name float-left">Jonathan Smith</span>
                <span class="time float-right">Just now</span>
                <p>Hello, this is an example msg</p>
            </div>
        </a>
        <a class="dropdown-item media" href="#">
            <span class="photo media-left"><img alt="avatar" src="images/avatar/2.jpg"></span>
            <div class="message media-body">
                <span class="name float-left">Jack Sanders</span>
                <span class="time float-right">5 minutes ago</span>
                <p>Lorem ipsum dolor sit amet, consectetur</p>
            </div>
        </a>
        <a class="dropdown-item media" href="#">
            <span class="photo media-left"><img alt="avatar" src="images/avatar/3.jpg"></span>
            <div class="message media-body">
                <span class="name float-left">Cheryl Wheeler</span>
                <span class="time float-right">10 minutes ago</span>
                <p>Hello, this is an example msg</p>
            </div>
        </a>
        <a class="dropdown-item media" href="#">
            <span class="photo media-left"><img alt="avatar" src="images/avatar/4.jpg"></span>
            <div class="message media-body">
                <span class="name float-left">Rachel Santos</span>
                <span class="time float-right">15 minutes ago</span>
                <p>Lorem ipsum dolor sit amet, consectetur</p>
            </div>
        </a>
    </div>
</div>
-->