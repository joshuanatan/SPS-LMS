<?php

class pdf {
    function __construct() {
        include_once APPPATH . '/third_party/fpdf181/fpdf.php';
    }
}

?>
