<?php
defined("BASEPATH") OR exit("No Direct Script");

class Mdgurutahunan extends CI_Model{
    public function select($where){
        return $this->db->get_where("guru_tahunan",$where);
    }
    public function insert($data){
        $this->db->insert("guru_tahunan",$data);
    }
    public function update($data,$where){
        $this->db->update("guru_tahunan",$data,$where);
    }
}