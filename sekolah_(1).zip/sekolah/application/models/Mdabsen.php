<?php
defined("BASEPATH") OR exit("No Direct Script");

class Mdabsen extends CI_Model{
    public function select($where){
        return $this->db->get_where("absen",$where);
    }
    public function insert($data){
        $this->db->insert("absen",$data);
    }
    public function update($data,$where){
        $this->db->update("absena",$data,$where);
    }
}