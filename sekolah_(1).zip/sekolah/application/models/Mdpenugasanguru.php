<?php
defined("BASEPATH") OR exit("No Direct Script");

class Mdpenugasanguru extends CI_Model{
    public function select($where){
        return $this->db->get_where("penugasan_guru",$where);
    }
    public function insert($data){
        $this->db->insert("penugasan_guru",$data);
    }
    public function update($data,$where){
        $this->db->update("penugasan_guru",$data,$where);
    }
}