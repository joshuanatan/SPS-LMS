<?php
defined("BASEPATH") OR exit("No Direct Script");

class Mdsiswa extends CI_Model{
    public function select($where){
        return $this->db->get_where("siswa",$where);
    }
    public function insert($data){
        $this->db->insert("siswa",$data);
    }
    public function update($data,$where){
        $this->db->update("siswa",$data,$where);
    }
}