<?php
defined("BASEPATH") OR exit("No Direct Script");

class Mdmatpel extends CI_Model{
    public function select($where){
        return $this->db->get_where("mata_pelajaran",$where);
    }
    public function insert($data){
        $this->db->insert("mata_pelajaran",$data);
    }
    public function update($data,$where){
        $this->db->update("mata_pelajaran",$data,$where);
    }
}