
<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Luxury Watches A Ecommerce Category Flat Bootstarp Resposive Website Template | Checkout :: w3layouts</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!--jQuery(necessary for Bootstrap's JavaScript plugins)-->
<script src="js/jquery-1.11.0.min.js"></script>
<!--Custom-Theme-files-->
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Luxury Watches Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--start-menu-->
<script src="js/simpleCart.min.js"> </script>
<link href="css/memenu.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="js/memenu.js"></script>
<script>$(document).ready(function(){$(".memenu").memenu();});</script>	
<!--dropdown-->
<script src="js/jquery.easydropdown.js"></script>			
</head>
<body> 
	
    
    <!--top-header-->
	<div class="top-header">
		<div class="container">
			<div class="top-header-main">
				<div class="col-md-6 top-header-left">
					<div class="drop">
                            <h5> Login </h5>
						<div class="clearfix"></div>
					</div>
				</div>
				<div class="col-md-6 top-header-left">
					<div class="cart box_1">
                        
                        
						<a href="checkout.html">
							 <div class="total">
								<span class="simpleCart_total"></span></div>
								<img src="images/cart-1.png" alt="" />
						</a>
                        
						<p class="simpleCart_empty">Empty Cart</p>
                        
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!--top-header-->
	
    
    <!--start-logo-->
	<div class="logo">
		<a href="index.html"><h1>Watch Corner</h1></a>
	</div>
	<!--start-logo-->
    
    
	<!--bottom-header-->
	<div class="header-bottom">
		<div class="container">
			<div class="header">
				<div class="col-md-9 header-left">
				<div class="top-nav">
                    
					<ul class="memenu skyblue">
                        
                        <li>
                        <a href="index.html">Home</a>
                        </li>
						
                        <li class="grid"><a href="#">Men</a>
							<div class="mepanel">
								<div class="row">
									
									<div class="col1 me-one">
										<h4>Popular Brands</h4>
										<ul>
                                            
                                            <li><a href="products.html">Fossil</a></li>
                                            <li><a href="products.html">Panerai</a></li>
											<li><a href="products-sevenfriday.html">Seven Friday</a></li>
											<li><a href="products.html">Tag Heuer</a></li>
											<li><a href="products.html">Tissot</a></li>
											
											
										</ul>		
									</div>
								</div>
							</div>
						</li>
                        
						<li class="grid"><a href="#">Women</a>
							<div class="mepanel">
								<div class="row">
									<div class="col1 me-one">
										<h4>Popular Brands</h4>
										<ul>
											<li><a href="products.html">Fossil</a></li>
											<li><a href="products.html">Michael Kors</a></li>
											<li><a href="products.html">Swarovski</a></li>
											<li><a href="products.html">Tag Heuer</a></li>
											<li><a href="products.html">Tissot</a></li>
											
										</ul>	
									</div>
								</div>
							</div>
						</li>
						
						<li class="grid"><a href="typo.html">Accessories</a>
				        <div class="mepanel">
								<div class="row">
									<div class="col1 me-one">
										<h4>Popular Brands</h4>
										<ul>
											<li><a href="products.html">Fossil</a></li>
											<li><a href="products.html">Tag Heuer</a></li>
											<li><a href="products.html">Tissot</a></li>
											
										</ul>	
									</div>
								</div> 
							</div>
                        </li>
                        
						<li class="grid"><a href="contact.html">About Us</a>
						</li>
                        
					</ul>
				</div>
				<div class="clearfix"> </div>
			</div>
                
			<div class="col-md-3 header-right"> 
				<div class="search-bar">
                    <!--search-->
					<input type="text" value="Search" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}">
					<input type="submit" value="">
				</div>
			</div>
			<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!--bottom-header-->
    
    <!--start-breadcrumbs-->
	<div class="breadcrumbs">
		<div class="container">
			<div class="breadcrumbs-main">
				<ol class="breadcrumb">
					<li> Home </li>
					<li> Cart </li>
					<li class="active"> Checkout </li>
				</ol>
			</div>
		</div>
	</div>
	<!--end-breadcrumbs-->
    
    
    
	<!--start-ckeckout-->
	<div class="ckeckout">
		<div class="container">
			<div class="ckeck-top heading">
				<h2>- CHECKOUT -</h2>
			</div>
            
            
			<div class="ckeckout-top">
			<div class="cart-items"> 
				<script>$(document).ready(function(c) {
					$('.close1').on('click', function(c){
						$('.cart-header').fadeOut('slow', function(c){
							$('.cart-header').remove();
						});
						});	  
					});
			   </script>
			<script>$(document).ready(function(c) {
					$('.close2').on('click', function(c){
						$('.cart-header1').fadeOut('slow', function(c){
							$('.cart-header1').remove();
						});
						});	  
					});
			   </script>
			   <script>$(document).ready(function(c) {
					$('.close3').on('click', function(c){
						$('.cart-header2').fadeOut('slow', function(c){
							$('.cart-header2').remove();
						});
						});	  
					});
			   </script>
				
			<div class="in-check" >
				<ul class="unit">
					<li><span>Item</span></li>
					<li><span>Product Name</span></li>		
					<li><span>Unit Price</span></li>
					<li><span>Delivery Details</span></li>
					<li> </li>
					<div class="clearfix"> </div>
				</ul>
                
				<ul class="cart-header">
					<div class="close1"> </div>
						<li class="ring-in"><a href="single.html" ><img src="images/tes2.png" class="img-responsive" alt=""></a>
						</li>
						<li><span class="name">Analog Watches</span></li>
						<li><span class="cost">$ 290.00</span></li>
						<li><span>Free</span>
						<p>Delivered in 2-3 business days</p></li>
					<div class="clearfix"> </div>
                    
                </ul>   
			</div>
                <a href="#" class="confirm">CONFIRM</a>
			</div>  
		 </div>
		</div>
	</div>
	<!--end-ckeckout-->
	
    <!--information-starts-->
	<div class="information">
		<div class="container">
			<div class="infor-top">
				<div class="col-md-3 infor-left">
					<h3>Follow Us</h3>
					<ul>
						<li><a href="#"><span class="fb"></span><h6>Facebook</h6></a></li>
						<li><a href="#"><span class="twit"></span><h6>Twitter</h6></a></li>
						<li><a href="#"><span class="google"></span><h6>Google+</h6></a></li>
					</ul>
				</div>
                
				<div class="col-md-3 infor-left">
					<h3>Information</h3>
					<ul>
						<li><a href="#"><p>Men</p></a></li>
						<li><a href="#"><p>Women</p></a></li>
						<li><a href="#"><p>Accessories</p></a></li>
						<li><a href="#"><p>About Us</p></a></li>
					</ul>
				</div>
				
				<div class="col-md-3 infor-left">
					<h3>Store Information</h3>
					<h4>Watch Corner,
						<span>Vila Permata,</span>
						Blok A3 no 32.</h4>
					<h5>+6282236689709</h5>	
					<p><a href="mailto:luih123.joshua@gmail.com">luih123.joshua@gmail.com</a></p>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!--information-end-->
    
    
	<!--footer-starts-->
	<div class="footer">
		<div class="container">
			<div class="footer-top">
				<div class="col-md-6 footer-left">
					<!--ratakiri-->
				</div>
				<div class="col-md-6 footer-right">					
					<p>© 2018 Watche Corner . </p>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!--footer-end-->	
</body>
</html>