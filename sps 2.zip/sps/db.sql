-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Mar 07, 2019 at 04:10 PM
-- Server version: 5.7.21
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `e-education`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignment_submission`
--

CREATE TABLE `assignment_submission` (
  `id_assignment_submission` varchar(250) NOT NULL,
  `id_siswa` varchar(250) NOT NULL,
  `id_dokumen` varchar(250) NOT NULL,
  `file_submission` varchar(250) NOT NULL,
  `status_assignment` tinyint(1) NOT NULL,
  `tgl_submit_assignment` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `assignment_submission`
--

INSERT INTO `assignment_submission` (`id_assignment_submission`, `id_siswa`, `id_dokumen`, `file_submission`, `status_assignment`, `tgl_submit_assignment`) VALUES
('S001_D001', 'S001', 'D001', 'Screen_Shot_2019-01-14_at_20.13.20.png', 0, '2019-03-07');

-- --------------------------------------------------------

--
-- Table structure for table `dokumen`
--

CREATE TABLE `dokumen` (
  `id_dokumen` varchar(250) NOT NULL,
  `id_mingguan` varchar(250) NOT NULL,
  `status_dokumen` tinyint(1) NOT NULL,
  `tgl_submit_dokumen` date NOT NULL,
  `file_assignment` varchar(100) NOT NULL,
  `id_jenis_dokumen` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dokumen`
--

INSERT INTO `dokumen` (`id_dokumen`, `id_mingguan`, `status_dokumen`, `tgl_submit_dokumen`, `file_assignment`, `id_jenis_dokumen`) VALUES
('D001', 'W1', 0, '2019-03-07', 'tes.docx', 'ASS');

-- --------------------------------------------------------

--
-- Table structure for table `guru_tahunan`
--

CREATE TABLE `guru_tahunan` (
  `id_gurutahunan` varchar(250) NOT NULL,
  `id_tahun_ajaran` varchar(250) NOT NULL,
  `id_guru` varchar(250) NOT NULL,
  `status_gurutahunan` tinyint(1) NOT NULL,
  `tgl_submit_gurutahunan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `guru_tahunan`
--

INSERT INTO `guru_tahunan` (`id_gurutahunan`, `id_tahun_ajaran`, `id_guru`, `status_gurutahunan`, `tgl_submit_gurutahunan`) VALUES
('HERY_1819', '1819', 'HERY', 0, '2019-03-07'),
('KUSNOPRASETYA_1819', '1819', 'KUSNOPRASETYA', 0, '2019-03-07');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal`
--

CREATE TABLE `jadwal` (
  `id_jadwal` varchar(250) NOT NULL,
  `id_penugasan` varchar(250) NOT NULL,
  `hari` varchar(50) NOT NULL,
  `jam_pelajaran` int(10) NOT NULL,
  `jumlah_jampel` int(10) NOT NULL,
  `status_jadwal` tinyint(1) NOT NULL,
  `tgl_submit_jadwal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jadwal`
--

INSERT INTO `jadwal` (`id_jadwal`, `id_penugasan`, `hari`, `jam_pelajaran`, `jumlah_jampel`, `status_jadwal`, `tgl_submit_jadwal`) VALUES
('IPA_1_1819_HERY_1', 'IPA_1_1819_HERY', 'Senin', 1, 2, 0, '2019-03-07');

-- --------------------------------------------------------

--
-- Table structure for table `jenis`
--

CREATE TABLE `jenis` (
  `id_jenis_dokumen` varchar(250) NOT NULL,
  `nama_jenis_dokumen` varchar(250) NOT NULL,
  `status_jenis_dokumen` tinyint(1) NOT NULL,
  `tgl_submit_jenis_dokumen` date NOT NULL,
  `peruntukan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jenis`
--

INSERT INTO `jenis` (`id_jenis_dokumen`, `nama_jenis_dokumen`, `status_jenis_dokumen`, `tgl_submit_jenis_dokumen`, `peruntukan`) VALUES
('ASS', 'Assignment', 0, '2019-03-07', 'Nilai'),
('UTS', 'Ujian Tengah Semester', 0, '2019-03-07', 'Nilai'),
('UAS', 'Ujian Akhir Semester', 0, '2019-03-07', 'Nilai');

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `id_kelas` varchar(250) NOT NULL,
  `jurusan` varchar(100) NOT NULL,
  `urutan` int(100) NOT NULL,
  `id_gurutahunan` varchar(250) NOT NULL,
  `status_kelas` tinyint(1) NOT NULL,
  `tgl_submit_kelas` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `jurusan`, `urutan`, `id_gurutahunan`, `status_kelas`, `tgl_submit_kelas`) VALUES
('IPA_1_1819', 'IPA', 1, 'HERY_1819', 0, '2019-03-07'),
('IPS_1_1819', 'IPS', 1, 'KUSNOPRASETYA_1819', 0, '2019-03-07');

-- --------------------------------------------------------

--
-- Table structure for table `kelas_siswa`
--

CREATE TABLE `kelas_siswa` (
  `id_kelas_siswa` varchar(250) NOT NULL,
  `id_siswa_angkatan` varchar(250) NOT NULL,
  `id_kelas` varchar(250) NOT NULL,
  `status_kelas_siswa` tinyint(1) NOT NULL,
  `tgl_submit_kelas_siswa` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kelas_siswa`
--

INSERT INTO `kelas_siswa` (`id_kelas_siswa`, `id_siswa_angkatan`, `id_kelas`, `status_kelas_siswa`, `tgl_submit_kelas_siswa`) VALUES
('IPA_1_1819_BRYANLIMING', 'S001_1819', 'IPA_1_1819', 0, '2019-03-07'),
('IPS_1_1819_JOVANHIDAYAT', 'S002_1819', 'IPS_1_1819', 0, '2019-03-07');

-- --------------------------------------------------------

--
-- Table structure for table `orang_tua`
--

CREATE TABLE `orang_tua` (
  `id_orangtua` varchar(250) NOT NULL,
  `id_user` varchar(250) NOT NULL,
  `pekerjaan` varchar(100) NOT NULL,
  `status_orangtua` tinyint(1) NOT NULL,
  `tgl_submit_orangtua` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orang_tua`
--

INSERT INTO `orang_tua` (`id_orangtua`, `id_user`, `pekerjaan`, `status_orangtua`, `tgl_submit_orangtua`) VALUES
('O001', 'U015', 'Manajer', 0, '2019-03-07'),
('O002', 'U022', 'Manajer', 0, '2019-03-07');

-- --------------------------------------------------------

--
-- Table structure for table `penilaian`
--

CREATE TABLE `penilaian` (
  `id_penilaian` varchar(250) NOT NULL,
  `id_kelas_siswa` varchar(250) NOT NULL,
  `id_jadwal` varchar(250) NOT NULL,
  `id_jenis_dokumen` varchar(250) NOT NULL,
  `nilai` int(10) NOT NULL,
  `status_penilaian` tinyint(1) NOT NULL,
  `tgl_submit_penilaian` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `penilaian`
--

INSERT INTO `penilaian` (`id_penilaian`, `id_kelas_siswa`, `id_jadwal`, `id_jenis_dokumen`, `nilai`, `status_penilaian`, `tgl_submit_penilaian`) VALUES
('UTS_IPA_1_1819_HERY_1_BRYANLIMING', 'IPA_1_1819_BRYANLIMING', 'IPA_1_1819_HERY_1', 'UTS', 90, 0, '2019-03-07');

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `id_quiz` varchar(250) NOT NULL,
  `id_mingguan` varchar(250) NOT NULL,
  `status_quiz` tinyint(1) NOT NULL,
  `tgl_submit_quiz` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`id_quiz`, `id_mingguan`, `status_quiz`, `tgl_submit_quiz`) VALUES
('Q1_W1_IPA_1_1819_HERY_1', 'W1_IPA_1_1819_HERY_1', 0, '2019-03-07');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `id_siswa` varchar(250) NOT NULL,
  `id_user` varchar(250) NOT NULL,
  `jurusan` varchar(100) NOT NULL,
  `id_orangtua` varchar(250) NOT NULL,
  `status_siswa` tinyint(1) NOT NULL,
  `tgl_submit_siswa` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`id_siswa`, `id_user`, `jurusan`, `id_orangtua`, `status_siswa`, `tgl_submit_siswa`) VALUES
('S001', 'U001', 'IPA', 'O001', 0, '2019-03-07'),
('S002', 'U002', 'IPS', 'O002', 0, '2019-03-07');

-- --------------------------------------------------------

--
-- Table structure for table `siswa_angkatan`
--

CREATE TABLE `siswa_angkatan` (
  `id_siswa_angkatan` varchar(250) NOT NULL,
  `id_siswa` varchar(250) NOT NULL,
  `id_tahun_ajaran` varchar(250) NOT NULL,
  `kelas` int(10) NOT NULL,
  `status_siswa_angkatan` tinyint(1) NOT NULL,
  `tgl_submit_siswa_angkatan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `siswa_angkatan`
--

INSERT INTO `siswa_angkatan` (`id_siswa_angkatan`, `id_siswa`, `id_tahun_ajaran`, `kelas`, `status_siswa_angkatan`, `tgl_submit_siswa_angkatan`) VALUES
('S001_1819', 'S001', '1819', 10, 0, '2019-03-07'),
('S002_1819', 'S002', '1819', 10, 0, '2019-03-07');

-- --------------------------------------------------------

--
-- Table structure for table `soal`
--

CREATE TABLE `soal` (
  `id_soal` varchar(250) NOT NULL,
  `pertanyaan` varchar(250) NOT NULL,
  `opsi1` varchar(250) NOT NULL,
  `opsi2` varchar(250) NOT NULL,
  `opsi3` varchar(250) NOT NULL,
  `opsi4` varchar(250) NOT NULL,
  `jawaban` varchar(250) NOT NULL,
  `id_quiz` varchar(250) NOT NULL,
  `status_soal` tinyint(1) NOT NULL,
  `tgl_submit_soal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `soal`
--

INSERT INTO `soal` (`id_soal`, `pertanyaan`, `opsi1`, `opsi2`, `opsi3`, `opsi4`, `jawaban`, `id_quiz`, `status_soal`, `tgl_submit_soal`) VALUES
('Q1_W1_IPA1_1_1819_HERY_1_S1', '15 * 2', '5', '20', '15', '30', '30', 'Q1_W1_IPA_1_1819_HERY_1', 0, '2019-03-07');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` varchar(250) NOT NULL,
  `nama_depan` varchar(100) NOT NULL,
  `nama_belakang` varchar(100) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `nomor_telepon` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `password` varchar(250) NOT NULL,
  `tgl_submit` date NOT NULL,
  `id_admin` varchar(250) NOT NULL,
  `status` int(11) NOT NULL,
  `id_role` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama_depan`, `nama_belakang`, `tanggal_lahir`, `nomor_telepon`, `email`, `alamat`, `password`, `tgl_submit`, `id_admin`, `status`, `id_role`) VALUES
('U001', 'Bryan', 'Liming', '1996-03-07', '081239123713', 'bryanliming@gmail.com', 'Serpong', '4dd39f49f898c062283963c187532af8', '2019-03-07', 'A001', 0, 'SISWA'),
('U002', 'Jovan', 'Hidayat', '1996-03-04', '08123983123', 'jovanhidayat@gmail.com', 'Citra', '4dd39f49f898c062283963c187532af8', '2019-03-07', 'A001', 0, 'SISWA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignment_submission`
--
ALTER TABLE `assignment_submission`
  ADD PRIMARY KEY (`id_assignment_submission`);

--
-- Indexes for table `kelas_siswa`
--
ALTER TABLE `kelas_siswa`
  ADD PRIMARY KEY (`id_kelas_siswa`);

--
-- Indexes for table `orang_tua`
--
ALTER TABLE `orang_tua`
  ADD PRIMARY KEY (`id_orangtua`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id_siswa`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);
