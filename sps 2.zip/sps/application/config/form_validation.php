<?php
$config = array(
        array(
                'field' => 'text_field',
                'label' => 'Text Field One',
                'rules' => 'required'
        ),
        array(
                'field' => 'min_text_field',
                'label' => 'Text Field Two',
                'rules' => 'required|min_length[8]'
        ),
        array(
                'field' => 'max_text_field',
                'label' => 'Text Field Three',
                'rules' => 'required|max_length[20]'
        )
);

$config = array(
		'group_one' => array(
				array(
						'field' => 'text_field',
						'label' => 'Text Field One',
						'rules' => 'required'
				)
     ),
		'group_two' => array(
				array(
                'field' => 'min_text_field',
                'label' => 'Text Field Two',
                'rules' => 'required|min_length[8]'
        ),
        array(
                'field' => 'max_text_field',
                'label' => 'Text Field Three',
                'rules' => 'required|max_length[20]'
        )
     )
);

$config = array(
		'validation/configuration' => array(
				array(
						'field' => 'max_text_field',
						'label' => 'Text Field Three',
						'rules' => 'required|max_length[20]'
				)
		)
);