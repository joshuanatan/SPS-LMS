<?php 
 
class siswa extends CI_Controller{
 
	function __construct(){
		parent::__construct();
		  
          $this->load->model(array('Mdsiswa','Mduser','Mdorangtua'));
          
	}
 
	public function index(){

        $where = NULL;
        $data['siswa']=$this->Mdsiswa->select($where)->result();
        $this->load->view('view1',$data);
    }
    
    function tambahsiswa(){
        $whereuser = array('id_role'=>"SISWA");
        $where = NULL;
        $data['user'] = $this->Mduser->select($whereuser)->result();
        $data['orangtua'] = $this->Mdorangtua->select($where)->result();
        
        $this->load->view('view',$data);
    }
    
    
    function simpansiswa(){
        $tangkapIdsiswa = $this->input->post('id_siswa');
        $tangkapIduser = $this->input->post('id_user');
        $tangkapJurusan = $this->input->post('jurusan');
        $tangkapIdorangtua = $this->input->post('id_orangtua');
        $tangkapStatussiswa = $this->input->post('status_siswa');

        $data = array(

            'id_siswa'=>$tangkapIdsiswa,
            'id_user'=>$tangkapIduser,
            'jurusan'=>$tangkapJurusan,
            'id_orangtua'=>$tangkapIdorangtua,
            'status_siswa'=>$tangkapStatussiswa,
            'tgl_submit_siswa'=>date('Y-m-d'),
        );
        
        $this->Mdsiswa->insert($data);
        redirect('siswa/tambahsiswa');
    
    }
    
    function editsiswa ($id_siswa){
        $whereuser = array('id_role'=>"SISWA");
        $where = NULL;
        $data['user'] = $this->Mduser->select($whereuser)->result();
        $data['orangtua'] = $this->Mdorangtua->select($where)->result();
        
        $where = array('id_siswa'=>$id_siswa);
        $data['siswa']=$this->Mdsiswa->select($where)->result();
        $this->load->view('view2',$data);
    }
        
       
    
    function updatesiswa ($id_siswa){
        
        $tangkapIduser = $this->input->post('id_user');
        $tangkapJurusan = $this->input->post('jurusan');
        $tangkapIdorangtua = $this->input->post('id_orangtua');
        $tangkapStatussiswa = $this->input->post('status_siswa');

        $data = array(

            
            'id_user'=>$tangkapIduser,
            'jurusan'=>$tangkapJurusan,
            'id_orangtua'=>$tangkapIdorangtua,
            'status_siswa'=>$tangkapStatussiswa,
            'tgl_submit_siswa'=>date('Y-m-d'),
        );
        
        $where = array('id_siswa'=>$id_siswa);
        $this->Mdsiswa->update($data,$where);
        redirect('siswa');
    
    }
        
    
    
    function hapussiswa ($id_siswa){
        
        $data = array(

            'status_siswa'=>"1",
        );
        
        $where = array('id_siswa'=>$id_siswa);
        $this->Mdsiswa->update($data,$where);
        redirect('siswa');
    }
	
}